package src.com.bean;

public interface UserDao {
	 public boolean find(String Account,String Password);
	 User selectByName(String Account);
	} 
