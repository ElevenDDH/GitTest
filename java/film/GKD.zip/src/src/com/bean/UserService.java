package src.com.bean;

public interface UserService {
    int judgeLogin(String Account,String Password);

}
